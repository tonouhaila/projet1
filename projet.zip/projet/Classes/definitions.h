

#ifndef __definitions_H__
#define __definitions_H__

#define transition_time 0.5
#define begin_time 2

#define ball_collision_bitmask 0x000001
#define obstacle_collision_bitmask 0x000002 


#endif // __definitions_H__
#include "level1.h"
#include "SimpleAudioEngine.h"
#include "definitions.h"
#include "ending.h"


USING_NS_CC;

 Scene* level1::createScene()
{
	auto scene = Scene::createWithPhysics();
	scene->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);

	auto layer = level1::create();
	layer->SetPhysicsWorld(scene->getPhysicsWorld());

	scene->addChild(layer);
	

    return scene;

}

bool level1::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }
	

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

	auto background = Sprite::create("backround-menu.PNG");
	background->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
	background->setScale(0.9);
	this->addChild(background, 0);
	
	auto border = Sprite::create("scene1-border.PNG");
	border->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
	border->setScale(0.4);
	this->addChild(border,1);
	auto rr = border->getContentSize().width-68;
	auto ss = border->getContentSize().height - 65;
	auto edgeBody = PhysicsBody::createEdgeBox(Size(rr,ss), PHYSICSBODY_MATERIAL_DEFAULT, 3);
	auto edgenode = Node::create();
	edgeBody->setCollisionBitmask(obstacle_collision_bitmask);
	edgeBody->setContactTestBitmask(true);
	edgenode->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
	edgenode->setScale(0.4);
	edgenode->setPhysicsBody(edgeBody);

	this->addChild(edgenode);

	auto pipe1 = Sprite::create("pipe.png");
	auto pipe1Body = PhysicsBody ::createBox(pipe1-> getContentSize());
	pipe1Body->setDynamic(false);
	pipe1Body->setCollisionBitmask(obstacle_collision_bitmask);
	pipe1Body->setContactTestBitmask(true);
	pipe1->setPhysicsBody(pipe1Body);
	pipe1->setPosition(Point(border->getContentSize().width / 6 + border->getContentSize().width / 3.5 + origin.x, border->getContentSize().height / 4.5 +origin.y));
	pipe1->setScale(0.45);
	
	auto pipe2 = Sprite::create("pipe.png");
	auto pipe2Body = PhysicsBody::createBox(pipe2->getContentSize());
	pipe2Body->setDynamic(false);
	pipe2Body->setCollisionBitmask(obstacle_collision_bitmask);
	pipe2Body->setContactTestBitmask(true);
	pipe2->setPhysicsBody(pipe2Body);
	pipe2->setPosition(Point(border->getContentSize().width / 6 + border->getContentSize().width / 2.75 + origin.x, border->getContentSize().height / 2.79 + origin.y));
	pipe2->setRotation(90.0f);
	pipe2->setScale(0.45);
	pipe2->setScaleY(0.2);

	auto pipe3 = Sprite::create("pipe.png");
	auto pipe3Body = PhysicsBody::createBox(pipe3->getContentSize());
	pipe3Body->setDynamic(false);
	pipe3Body->setCollisionBitmask(obstacle_collision_bitmask);
	pipe3Body->setContactTestBitmask(true);
	pipe3->setPhysicsBody(pipe3Body);
	pipe3->setPosition(Point(border->getContentSize().width / 9 +border->getContentSize().width / 2 + origin.x, border->getContentSize().height / 3 - 55 + origin.y));
	pipe3->setScale(0.45);
	pipe3->setScaleY(0.37);

	auto pipe4 = Sprite::create("pipe.png");
	auto pipe4Body = PhysicsBody::createBox(pipe4->getContentSize());
	pipe4Body->setDynamic(false);
	pipe4Body->setCollisionBitmask(obstacle_collision_bitmask);
	pipe4Body->setContactTestBitmask(true);
	pipe4->setPhysicsBody(pipe4Body);
	pipe4->setPosition(Point(border->getContentSize().width / 6 + border->getContentSize().width / 2.75 + 19 + origin.x, border->getContentSize().height / 4 - 75 + origin.y));
	pipe4->setRotation(90.0f);
	pipe4->setScale(0.45);
	pipe4->setScaleY(0.1);

	auto pipe5 = Sprite::create("pipe.png");
	auto pipe5Body = PhysicsBody::createBox(pipe5->getContentSize());
	pipe5Body->setDynamic(false);
	pipe5Body->setCollisionBitmask(obstacle_collision_bitmask);
	pipe5Body->setContactTestBitmask(true);
	pipe5->setPhysicsBody(pipe5Body);
	pipe5->setPosition(Point(border->getContentSize().width / 2+19 + origin.x, border->getContentSize().height / 3 - 75 + origin.y));
	pipe5->setScale(0.45);
	pipe5->setScaleY(0.25);

	
	auto balle = Sprite::create("ball.png");
	balle->setPosition(Point(visibleSize.width / 2 - 60 + origin.x, visibleSize.height / 2 -90 + origin.y));
	balle->setScale(0.7);
	
	auto ballBody = PhysicsBody::createCircle(balle->getContentSize().width / 2);
	ballBody->setDynamic(false);
	ballBody->setCollisionBitmask( ball_collision_bitmask );
	ballBody->setContactTestBitmask(true);
	balle->setPhysicsBody(ballBody);
	this->addChild(balle, 100);

	this->addChild(pipe1);
	this->addChild(pipe2);
	this->addChild(pipe3);
	this->addChild(pipe4);
	this->addChild(pipe5);

	auto contactListener = EventListenerPhysicsContact::create();
	contactListener->onContactBegin = CC_CALLBACK_1(level1::onContactBegin, this);
	Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(contactListener, this);
	
	auto keyboardListener = EventListenerKeyboard::create();
	keyboardListener->onKeyPressed = CC_CALLBACK_2(level1::keyPressed, this);
	keyboardListener->onKeyReleased = CC_CALLBACK_2(level1::keyReleased, this);
	Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(keyboardListener, this);


	
    return true;	
}

bool level1::onContactBegin(cocos2d::PhysicsContact &contact)
{
	bool result = false;
	PhysicsBody *a = contact.getShapeA()->getBody();
	PhysicsBody *b = contact.getShapeB()->getBody();

	if (( ball_collision_bitmask == a->getCollisionBitmask() && obstacle_collision_bitmask == b->getCollisionBitmask() )||(ball_collision_bitmask == b->getCollisionBitmask() && obstacle_collision_bitmask == a->getCollisionBitmask()))   
	{


	}
	
	
	return result;
}
void level1::keyPressed(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event)
{

}
void level1::keyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event *event)
{

}
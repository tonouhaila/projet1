

#ifndef __bigining_SCENE_H__
#define __bigining_SCENE_H__

#include "cocos2d.h"

class biginingScene : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();
	
    virtual bool init();
    
   
private:
	void GoToMainMenuScene(float dt);
    // implement the "static create()" method manually
    CREATE_FUNC(biginingScene);
};

#endif // __biginingScene_SCENE_H__

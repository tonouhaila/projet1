#include "GameScene.h"
#include "GameSprite.h"
#include "Header.h"
int GameScene::count = 0;
GameScene::GameScene() {
	ismoving = false;
	_direction_x = 0;
	_direction_y = 0;
}
GameScene::~GameScene() {

}
void GameScene::update(float dt) {
	if(ismoving==true) {
		_ball->setPosition(_ball->getPosition().x +  _direction_x, _ball->getPosition().y + _direction_y);
	}
	for (auto _sprites : _collidsprites) {
		
		if (_direction_x == 0 && _direction_y == 1) {
			if (_ball->getPositionX() == _sprites->getPositionX() && _ball->getPositionY() == _sprites->getPositionY() - 10) {
				ismoving = false;
			}
		}
		if (_direction_x == 0 && _direction_y == -1) {
			if (_ball->getPositionX() == _sprites->getPositionX() && _ball->getPositionY() == _sprites->getPositionY() + 10) {
				ismoving = false;
			}
		}
		if (_direction_x == 1 && _direction_y == 0) {
			if (_ball->getPositionX() == _sprites->getPositionX()-10 && _ball->getPositionY() == _sprites->getPositionY()) {
				ismoving = false;
			}
		}
		if (_direction_x == -1 && _direction_y == 0) {
			if (_ball->getPositionX() == _sprites->getPositionX() +10 && _ball->getPositionY() == _sprites->getPositionY() ) {
				ismoving = false;
			}
		}

	}
	for (auto _mysprites : _spritevector) {
			if (_ball->getPosition() == _mysprites->getPosition() && _mysprites->iscolored == false) {
				_mysprites->changecolor(Color3B(10, 255, 100));
				laith++;
			}
	}
	if (laith == end) {
		count++;
		auto scene = Scene::create();
		auto layer = GameScene::create();
		scene->addChild(layer);
		director->getInstance()->replaceScene(TransitionFade::create(1, scene));
	}
}
EventListenerKeyboard* GameScene::onKeyBoardEvent() {
	auto listener = EventListenerKeyboard::create();
	listener->onKeyPressed = [=](EventKeyboard::KeyCode _keycode, Event* event) {
		if (!ismoving) {
			switch (_keycode) {
			case EventKeyboard::KeyCode::KEY_UP_ARROW:
				_direction_y = 1;
				_direction_x = 0;
				ismoving = true;
				break;
			case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
				_direction_y = -1;
				_direction_x = 0;
				ismoving = true;
				break;
			case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
				_direction_x = -1;
				_direction_y = 0;
				ismoving = true;
				break;
			case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
				_direction_x = 1;
				_direction_y = 0;
				ismoving = true;
				break;
			}
		}
	};
	return listener;
}
Scene* GameScene::scene() {
	auto scene = Scene::create();
	auto layer = GameScene::create();
	scene->addChild(layer);
	return scene;
}
bool GameScene::init() {
	if (!Layer::init()) {
	return false;
	}
	if (count == 0) {
		end = 360;
		auto _array = arraylevel1;
		for (auto i = 0; i <= 8; i++) {
			for (auto j = 0; j <= 8; j++) {
				for (auto x = 0; x < 9; x++) {
					if ((i == _array[x][0] && j == _array[x][1]) || i == 0 || i == 8 || j == 0 || j == 8) {
						auto _sprite = GameSprite::gameSpriteinit();
						_sprite->setPosition(Vec2(150 + i * 10, 150 + j * 10));
						_sprite->setColor(Color3B(52, 255, 255));
						_collidsprites.pushBack(_sprite);
						this->addChild(_sprite);
						break;
					}
					else {

						auto _sprite = GameSprite::gameSpriteinit();
						_sprite->setPosition(Vec2(150 + i * 10, 150 + j * 10));
						_sprite->setColor(Color3B(100, 50, 25));
						_spritevector.pushBack(_sprite);
						this->addChild(_sprite);
					}
				}
			}
		}
	}

	if (count == 1) {
		end = 684;
		auto _array = arraylevel2;
		for (auto i = 0; i <= 8; i++) {
			for (auto j = 0; j <= 9; j++) {
				for (auto x = 0; x < 18; x++) {
					if ((i == _array[x][0] && j == _array[x][1]) || i == 0 || i == 8 || j == 0 || j == 9) {
						auto _sprite = GameSprite::gameSpriteinit();
						_sprite->setPosition(Vec2(150 + i * 10, 150 + j * 10));
						_sprite->setColor(Color3B(255, 255, 255));
						_collidsprites.pushBack(_sprite);
						this->addChild(_sprite);
						break;
					}
					else {
						auto _sprite = GameSprite::gameSpriteinit();
						_sprite->setPosition(Vec2(150 + i * 10, 150 + j * 10));
						_sprite->setColor(Color3B(100, 50, 25));
						_spritevector.pushBack(_sprite);
						this->addChild(_sprite);
					}
				}
			}
		}
	}
	_ball = Sprite::create("icon.png");
	_ball->setPosition(Vec2(160, 160));
	_ball->setScale(0.3);
	this->addChild(_ball);
	this->scheduleUpdate();
	auto eventListener = onKeyBoardEvent();
	this->_eventDispatcher->addEventListenerWithSceneGraphPriority(eventListener, _ball);
	return true;
}
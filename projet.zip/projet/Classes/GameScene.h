#pragma once
#include "cocos2d.h"
#include "GameSprite.h"
using namespace cocos2d;

class GameScene : public Layer
{
private:
	Vector<GameSprite*> _spritevector;
	Vector<GameSprite*> _collidsprites;
	bool ismoving = false;
	int _direction_x = 0;
	int _direction_y = 0;
	int end;
	int laith = 0;
public:
	static int count;
	Director* director;
	GameScene();
	virtual ~GameScene();
	Sprite* _ball;
	bool init();
	static Scene* scene();
	CREATE_FUNC(GameScene);
	EventListenerKeyboard* onKeyBoardEvent();
	void update(float dt);
};


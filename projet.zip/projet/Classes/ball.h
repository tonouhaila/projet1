#ifndef __ball_SCENE_H__
#define __ball_SCENE_H__

#include "cocos2d.h"

class ball {

private:
	ball( cocos2d::Layer *layer);
private:
	cocos2d::Size visibleSize;
	cocos2d::Vec2 origin;
	cocos2d::Sprite *balle;
	void goUp();
};

#endif // __ball_SCENE_H__

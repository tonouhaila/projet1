#include "level2.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;


Scene* level2::createScene()
{
    return level2::create();
}

bool level2::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

 
    return true;

	
	
}
	

		
		



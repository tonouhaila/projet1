#include "ball.h"
#include "SimpleAudioEngine.h"
#include "definitions.h"

USING_NS_CC;

ball::ball( cocos2d::Layer *layer)
{
	visibleSize = Director::getInstance()->getVisibleSize();
	origin = Director::getInstance()->getVisibleOrigin();
	balle = Sprite::create("ball.png");
	balle->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
	balle->setScale(0.5);
	auto ballBody = PhysicsBody::createCircle( balle->getContentSize().width/2 );
	balle->setPhysicsBody(ballBody);

	layer->addChild(balle, 100);

	
}
   
		
		



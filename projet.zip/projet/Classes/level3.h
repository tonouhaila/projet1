#ifndef __level3_SCENE_H__
#define __level3_SCENE_H__

#include "cocos2d.h"

class level3 : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
    
   
    
    // implement the "static create()" method manually
    CREATE_FUNC(level3);
};

#endif // __biginingScene_SCENE_H__

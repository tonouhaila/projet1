

#ifndef __ending_SCENE_H__
#define __ending_SCENE_H__

#include "cocos2d.h"

class ending : public cocos2d::Scene
{
public:
    static ending::Scene* createScene();

    virtual bool init();
    
   
    
    // implement the "static create()" method manually
    CREATE_FUNC(ending);
};

#endif // __biginingScene_SCENE_H__

#include "level3.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;


Scene* level3::createScene()
{
    return level3::create();
}

bool level3::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

   
    return true;

	
	
}
	

		
		


